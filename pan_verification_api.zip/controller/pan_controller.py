from fastapi import APIRouter, HTTPException
from models.pan_model import PANRequest
import requests

router = APIRouter()

HEADERS = {"Content-Type": "application/json"}

@router.post("/verify_pan/")
def verify_pan(request: PANRequest):
    try:
        payload = {
            "header": {
                "User_ID": request.User_ID,
                "Records_count": request.Records_count,
                "Request_time": request.Request_time,
                "Transaction_ID": request.Transaction_ID,
                "Version": request.Version
            },
            "request": {
                "inputData": [data.dict() for data in request.inputData],
                "signature": request.signature
            }
        }

        try:
            response = requests.post(EXTERNAL_API_ENDPOINT, json=payload, headers=HEADERS, verify=False)
            response.raise_for_status()
            return {"status_code": response.status_code, "response": response.json()}
        except requests.exceptions.RequestException as e:
            raise HTTPException(status_code=502, detail=f"Request to external API failed: {str(e)}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")