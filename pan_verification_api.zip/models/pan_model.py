from pydantic import BaseModel
from typing import List

class PANData(BaseModel):
    pan: str
    name: str
    fathername: str
    dob: str  # Format: dd-mm-yyyy

class PANRequest(BaseModel):
    User_ID: str
    Records_count: int
    Request_time: str
    Transaction_ID: str
    Version: str
    inputData: List[PANData]
    signature: str